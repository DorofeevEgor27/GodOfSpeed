using System.Collections.Generic;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;
using UnityEngine.Splines;

namespace GodOfSpeed.EditorTools
{
    public sealed class TerrainSplineRoadPainterWindow : EditorWindow
    {
        private const int MinSplineSamples = 8;
        private const float MinRoadWidth = 0.1f;

        [SerializeField] private Terrain terrain;
        [SerializeField] private SplineContainer spline;
        [SerializeField] private TerrainLayer roadLayer;
        [SerializeField] private TerrainLayer edgeLayer;
        [SerializeField, Min(MinRoadWidth)] private float roadWidth = 8f;
        [SerializeField, Min(0f)] private float edgeSoftness = 2f;
        [SerializeField, Min(0f)] private float edgeWidth = 3f;
        [SerializeField, Range(0f, 1f)] private float edgeStrength = 0.45f;
        [SerializeField, Range(0f, 1f)] private float edgeBreakup = 0.35f;
        [SerializeField] private bool paintEdgeOnlyOutsideRoad = true;
        [SerializeField, Range(8, 512)] private int splineSamples = 160;
        [SerializeField, Range(0f, 1f)] private float paintStrength = 1f;

        [MenuItem("Tools/God Of Speed/Terrain Road Painter")]
        private static void Open()
        {
            GetWindow<TerrainSplineRoadPainterWindow>("Road Painter");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Paint Terrain Road From Spline", EditorStyles.boldLabel);
            terrain = (Terrain)EditorGUILayout.ObjectField("Terrain", terrain, typeof(Terrain), true);
            spline = (SplineContainer)EditorGUILayout.ObjectField("Spline", spline, typeof(SplineContainer), true);
            roadLayer = (TerrainLayer)EditorGUILayout.ObjectField("Road Layer", roadLayer, typeof(TerrainLayer), false);
            edgeLayer = (TerrainLayer)EditorGUILayout.ObjectField("Edge Layer", edgeLayer, typeof(TerrainLayer), false);

            EditorGUILayout.Space(8f);

            roadWidth = EditorGUILayout.FloatField("Road Width", Mathf.Max(MinRoadWidth, roadWidth));
            edgeSoftness = EditorGUILayout.FloatField("Soft Edge", Mathf.Max(0f, edgeSoftness));
            edgeWidth = EditorGUILayout.FloatField("Edge Width", Mathf.Max(0f, edgeWidth));
            edgeStrength = EditorGUILayout.Slider("Edge Strength", edgeStrength, 0f, 1f);
            edgeBreakup = EditorGUILayout.Slider("Edge Breakup", edgeBreakup, 0f, 1f);
            paintEdgeOnlyOutsideRoad = EditorGUILayout.Toggle("Edge Only Outside", paintEdgeOnlyOutsideRoad);
            splineSamples = EditorGUILayout.IntSlider("Spline Samples", splineSamples, MinSplineSamples, 512);
            paintStrength = EditorGUILayout.Slider("Paint Strength", paintStrength, 0f, 1f);

            EditorGUILayout.Space(12f);

            using (new EditorGUI.DisabledScope(!CanPaint()))
            {
                if (GUILayout.Button("Paint Road"))
                {
                    PaintRoad();
                }
            }
        }

        private bool CanPaint()
        {
            return terrain != null
                && terrain.terrainData != null
                && spline != null
                && spline.Spline != null
                && spline.Spline.Count >= 2
                && roadLayer != null
                && paintStrength > 0f;
        }

        private void PaintRoad()
        {
            TerrainData terrainData = terrain.terrainData;
            List<Vector3> points = SampleSplineWorldPoints();
            if (points.Count < 2)
            {
                Debug.LogWarning("Spline must have at least two sampled points.", spline);
                return;
            }

            if (!TryGetPaintRect(terrainData, points, out RectInt paintRect))
            {
                Debug.LogWarning("Spline is outside the terrain bounds.", terrain);
                return;
            }

            int roadLayerIndex = EnsureTerrainLayer(terrainData, roadLayer);
            if (roadLayerIndex < 0)
            {
                Debug.LogWarning("Road layer was not added to the terrain.", terrain);
                return;
            }

            int edgeLayerIndex = GetEdgeLayerIndex(terrainData);

            Undo.RegisterCompleteObjectUndo(terrainData, "Paint Terrain Road");

            try
            {
                float[,,] alphamaps = terrainData.GetAlphamaps(paintRect.x, paintRect.y, paintRect.width, paintRect.height);
                PaintAlphamaps(terrainData, points, paintRect, roadLayerIndex, edgeLayerIndex, alphamaps);
                terrainData.SetAlphamaps(paintRect.x, paintRect.y, alphamaps);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            EditorUtility.SetDirty(terrainData);
            Debug.Log($"Painted terrain road on '{terrain.name}' from spline '{spline.name}'.", terrain);
        }

        private int GetEdgeLayerIndex(TerrainData terrainData)
        {
            if (edgeLayer == null || edgeLayer == roadLayer || edgeWidth <= 0f || edgeStrength <= 0f)
            {
                return -1;
            }

            return EnsureTerrainLayer(terrainData, edgeLayer);
        }

        private int EnsureTerrainLayer(TerrainData terrainData, TerrainLayer layer)
        {
            TerrainLayer[] layers = terrainData.terrainLayers;
            for (int i = 0; i < layers.Length; i++)
            {
                if (layers[i] == layer)
                {
                    return i;
                }
            }

            Undo.RegisterCompleteObjectUndo(terrainData, "Add Terrain Road Layer");

            var expandedLayers = new TerrainLayer[layers.Length + 1];
            for (int i = 0; i < layers.Length; i++)
            {
                expandedLayers[i] = layers[i];
            }

            expandedLayers[^1] = layer;
            terrainData.terrainLayers = expandedLayers;
            return expandedLayers.Length - 1;
        }

        private List<Vector3> SampleSplineWorldPoints()
        {
            int samples = Mathf.Max(MinSplineSamples, splineSamples);
            var points = new List<Vector3>(samples);

            for (int i = 0; i < samples; i++)
            {
                float t = samples == 1 ? 0f : i / (samples - 1f);
                points.Add(ToVector3(spline.EvaluatePosition(t)));
            }

            return points;
        }

        private bool TryGetPaintRect(TerrainData terrainData, List<Vector3> points, out RectInt paintRect)
        {
            Vector3 terrainPosition = terrain.transform.position;
            Vector3 terrainSize = terrainData.size;
            float paintRadius = GetMaxPaintRadius();

            float minX = float.PositiveInfinity;
            float maxX = float.NegativeInfinity;
            float minZ = float.PositiveInfinity;
            float maxZ = float.NegativeInfinity;

            foreach (Vector3 point in points)
            {
                minX = Mathf.Min(minX, point.x - paintRadius);
                maxX = Mathf.Max(maxX, point.x + paintRadius);
                minZ = Mathf.Min(minZ, point.z - paintRadius);
                maxZ = Mathf.Max(maxZ, point.z + paintRadius);
            }

            float terrainMinX = terrainPosition.x;
            float terrainMaxX = terrainPosition.x + terrainSize.x;
            float terrainMinZ = terrainPosition.z;
            float terrainMaxZ = terrainPosition.z + terrainSize.z;

            if (maxX < terrainMinX || minX > terrainMaxX || maxZ < terrainMinZ || minZ > terrainMaxZ)
            {
                paintRect = default;
                return false;
            }

            int alphaWidth = terrainData.alphamapWidth;
            int alphaHeight = terrainData.alphamapHeight;
            int xMin = WorldXToAlphaFloor(minX, terrainPosition, terrainSize, alphaWidth);
            int xMax = WorldXToAlphaCeil(maxX, terrainPosition, terrainSize, alphaWidth);
            int yMin = WorldZToAlphaFloor(minZ, terrainPosition, terrainSize, alphaHeight);
            int yMax = WorldZToAlphaCeil(maxZ, terrainPosition, terrainSize, alphaHeight);

            xMin = Mathf.Clamp(xMin, 0, alphaWidth - 1);
            xMax = Mathf.Clamp(xMax, 0, alphaWidth - 1);
            yMin = Mathf.Clamp(yMin, 0, alphaHeight - 1);
            yMax = Mathf.Clamp(yMax, 0, alphaHeight - 1);

            if (xMax < xMin || yMax < yMin)
            {
                paintRect = default;
                return false;
            }

            paintRect = new RectInt(xMin, yMin, xMax - xMin + 1, yMax - yMin + 1);
            return true;
        }

        private void PaintAlphamaps(
            TerrainData terrainData,
            List<Vector3> points,
            RectInt paintRect,
            int roadLayerIndex,
            int edgeLayerIndex,
            float[,,] alphamaps)
        {
            Vector3 terrainPosition = terrain.transform.position;
            Vector3 terrainSize = terrainData.size;
            int alphaWidth = terrainData.alphamapWidth;
            int alphaHeight = terrainData.alphamapHeight;
            int layerCount = terrainData.alphamapLayers;
            float innerRadius = roadWidth * 0.5f;

            for (int y = 0; y < paintRect.height; y++)
            {
                float progress = paintRect.height <= 1 ? 1f : y / (paintRect.height - 1f);
                EditorUtility.DisplayProgressBar("Painting Terrain Road", "Painting alphamap...", progress);

                int alphaY = paintRect.y + y;
                float worldZ = AlphaYToWorldZ(alphaY, terrainPosition, terrainSize, alphaHeight);

                for (int x = 0; x < paintRect.width; x++)
                {
                    int alphaX = paintRect.x + x;
                    float worldX = AlphaXToWorldX(alphaX, terrainPosition, terrainSize, alphaWidth);
                    float distance = GetDistanceToSpline(new Vector2(worldX, worldZ), points);
                    float edgeOffset = GetEdgeOffset(worldX, worldZ);
                    float localInnerRadius = Mathf.Max(MinRoadWidth * 0.5f, innerRadius + edgeOffset);
                    float localOuterRadius = localInnerRadius + edgeSoftness;
                    float localEdgeOuterRadius = localOuterRadius + edgeWidth;

                    if (distance > localEdgeOuterRadius)
                    {
                        continue;
                    }

                    if (edgeLayerIndex >= 0)
                    {
                        float edgeAmount = GetEdgeAmount(distance, localInnerRadius, localOuterRadius, localEdgeOuterRadius) * edgeStrength * paintStrength;
                        ApplyLayerWeight(alphamaps, x, y, edgeLayerIndex, edgeAmount, layerCount);
                    }

                    float roadAmount = GetRoadAmount(distance, localInnerRadius, localOuterRadius) * paintStrength;
                    ApplyLayerWeight(alphamaps, x, y, roadLayerIndex, roadAmount, layerCount);
                }
            }
        }

        private float GetMaxPaintRadius()
        {
            float radius = roadWidth * 0.5f + edgeSoftness + GetMaxEdgeOffset();
            if (edgeLayer != null && edgeLayer != roadLayer && edgeWidth > 0f && edgeStrength > 0f)
            {
                radius += edgeWidth;
            }

            return radius;
        }

        private float GetMaxEdgeOffset()
        {
            if (edgeBreakup <= 0f)
            {
                return 0f;
            }

            return Mathf.Max(0.1f, edgeSoftness + edgeWidth * 0.35f) * edgeBreakup;
        }

        private float GetEdgeOffset(float worldX, float worldZ)
        {
            if (edgeBreakup <= 0f)
            {
                return 0f;
            }

            float noiseScale = 0.075f;
            float noise = Mathf.PerlinNoise(worldX * noiseScale, worldZ * noiseScale) * 2f - 1f;
            return noise * GetMaxEdgeOffset();
        }

        private static float GetRoadAmount(float distance, float innerRadius, float outerRadius)
        {
            if (distance <= innerRadius || Mathf.Approximately(innerRadius, outerRadius))
            {
                return 1f;
            }

            float fade = 1f - Mathf.InverseLerp(innerRadius, outerRadius, distance);
            return Mathf.SmoothStep(0f, 1f, fade);
        }

        private static float GetOuterEdgeAmount(float distance, float roadOuterRadius, float edgeOuterRadius)
        {
            if (distance < roadOuterRadius)
            {
                return 0f;
            }

            float fadeOut = 1f - Mathf.InverseLerp(roadOuterRadius, edgeOuterRadius, distance);
            return Mathf.SmoothStep(0f, 1f, fadeOut);
        }

        private float GetEdgeAmount(float distance, float innerRadius, float roadOuterRadius, float edgeOuterRadius)
        {
            if (paintEdgeOnlyOutsideRoad)
            {
                return GetOuterEdgeAmount(distance, roadOuterRadius, edgeOuterRadius);
            }

            if (distance <= innerRadius || distance >= edgeOuterRadius)
            {
                return 0f;
            }

            if (distance <= roadOuterRadius)
            {
                float fadeIn = Mathf.InverseLerp(innerRadius, roadOuterRadius, distance);
                return Mathf.SmoothStep(0f, 1f, fadeIn);
            }

            float fadeOut = 1f - Mathf.InverseLerp(roadOuterRadius, edgeOuterRadius, distance);
            return Mathf.SmoothStep(0f, 1f, fadeOut);
        }

        private static void ApplyLayerWeight(float[,,] alphamaps, int x, int y, int targetLayer, float targetWeight, int layerCount)
        {
            targetWeight = Mathf.Clamp01(targetWeight);
            float currentWeight = alphamaps[y, x, targetLayer];
            if (targetWeight <= currentWeight)
            {
                return;
            }

            float currentOtherWeight = 1f - currentWeight;
            float newOtherWeight = 1f - targetWeight;

            for (int layer = 0; layer < layerCount; layer++)
            {
                if (layer == targetLayer)
                {
                    alphamaps[y, x, layer] = targetWeight;
                    continue;
                }

                alphamaps[y, x, layer] = currentOtherWeight > 0.0001f
                    ? alphamaps[y, x, layer] * newOtherWeight / currentOtherWeight
                    : newOtherWeight / Mathf.Max(1, layerCount - 1);
            }
        }

        private float GetDistanceToSpline(Vector2 point, List<Vector3> points)
        {
            float nearestDistanceSqr = float.PositiveInfinity;

            for (int i = 1; i < points.Count; i++)
            {
                Vector2 a = new(points[i - 1].x, points[i - 1].z);
                Vector2 b = new(points[i].x, points[i].z);
                nearestDistanceSqr = Mathf.Min(nearestDistanceSqr, DistanceToSegmentSqr(point, a, b));
            }

            if (spline.Spline.Closed)
            {
                Vector2 a = new(points[^1].x, points[^1].z);
                Vector2 b = new(points[0].x, points[0].z);
                nearestDistanceSqr = Mathf.Min(nearestDistanceSqr, DistanceToSegmentSqr(point, a, b));
            }

            return Mathf.Sqrt(nearestDistanceSqr);
        }

        private static float DistanceToSegmentSqr(Vector2 point, Vector2 a, Vector2 b)
        {
            Vector2 segment = b - a;
            float segmentLengthSqr = segment.sqrMagnitude;
            if (segmentLengthSqr <= 0.0001f)
            {
                return (point - a).sqrMagnitude;
            }

            float t = Mathf.Clamp01(Vector2.Dot(point - a, segment) / segmentLengthSqr);
            Vector2 closest = a + segment * t;
            return (point - closest).sqrMagnitude;
        }

        private static int WorldXToAlphaFloor(float worldX, Vector3 terrainPosition, Vector3 terrainSize, int alphaWidth)
        {
            float normalized = Mathf.InverseLerp(terrainPosition.x, terrainPosition.x + terrainSize.x, worldX);
            return Mathf.FloorToInt(normalized * (alphaWidth - 1));
        }

        private static int WorldXToAlphaCeil(float worldX, Vector3 terrainPosition, Vector3 terrainSize, int alphaWidth)
        {
            float normalized = Mathf.InverseLerp(terrainPosition.x, terrainPosition.x + terrainSize.x, worldX);
            return Mathf.CeilToInt(normalized * (alphaWidth - 1));
        }

        private static int WorldZToAlphaFloor(float worldZ, Vector3 terrainPosition, Vector3 terrainSize, int alphaHeight)
        {
            float normalized = Mathf.InverseLerp(terrainPosition.z, terrainPosition.z + terrainSize.z, worldZ);
            return Mathf.FloorToInt(normalized * (alphaHeight - 1));
        }

        private static int WorldZToAlphaCeil(float worldZ, Vector3 terrainPosition, Vector3 terrainSize, int alphaHeight)
        {
            float normalized = Mathf.InverseLerp(terrainPosition.z, terrainPosition.z + terrainSize.z, worldZ);
            return Mathf.CeilToInt(normalized * (alphaHeight - 1));
        }

        private static float AlphaXToWorldX(int alphaX, Vector3 terrainPosition, Vector3 terrainSize, int alphaWidth)
        {
            float normalized = alphaWidth <= 1 ? 0f : alphaX / (alphaWidth - 1f);
            return terrainPosition.x + normalized * terrainSize.x;
        }

        private static float AlphaYToWorldZ(int alphaY, Vector3 terrainPosition, Vector3 terrainSize, int alphaHeight)
        {
            float normalized = alphaHeight <= 1 ? 0f : alphaY / (alphaHeight - 1f);
            return terrainPosition.z + normalized * terrainSize.z;
        }

        private static Vector3 ToVector3(float3 value)
        {
            return new Vector3(value.x, value.y, value.z);
        }
    }
}
