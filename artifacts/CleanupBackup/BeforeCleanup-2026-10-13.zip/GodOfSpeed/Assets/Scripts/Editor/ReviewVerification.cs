using System;
using System.Reflection;
using GodOfSpeed.Racing;
using UnityEditor;
using UnityEngine;
using UnityEngine.Splines;

public static class ReviewVerification
{
    private const BindingFlags Flags = BindingFlags.NonPublic | BindingFlags.Instance;
    private static int passed;

    public static void Run()
    {
        var car = new GameObject("Temporary review verification");
        car.SetActive(false);
        try
        {
            var body = car.AddComponent<Rigidbody>();
            var left = Wheel(car.transform, "Left");
            var right = Wheel(car.transform, "Right");
            var driver = car.AddComponent<PhysicsSplineCarDriver>();
            Set(driver, "body", body);
            Set(driver, "frontRightWheel", left);
            Call(driver, "AssignMissingWheelsFromChildren");
            Check(Get<WheelCollider>(driver, "frontLeftWheel") == right, "Partial assignment keeps wheels distinct");

            Set(driver, "frontLeftWheel", left);
            Set(driver, "frontRightWheel", right);
            Call(driver, "Awake");
            Check(true, "Awake without spline does not throw");

            Set(driver, "speedKmh", 0f);
            Call(driver, "DriveWheels");
            Check(left.motorTorque == 0f && right.motorTorque == 0f && left.brakeTorque > 0f, "Zero speed has no engine torque and applies brakes");
            Set(driver, "speedKmh", 20f);
            Call(driver, "DriveWheels");
            Check(left.motorTorque > 0f && right.motorTorque > 0f, "Positive target speed still drives");
            Call(driver, "FixedUpdate");
            Check(left.motorTorque == 0f && right.motorTorque == 0f, "Missing spline clears previous engine torque");

            left.motorTorque = right.motorTorque = 10f;
            left.steerAngle = right.steerAngle = 12f;
            Call(driver, "OnDisable");
            Check(left.motorTorque == 0f && right.motorTorque == 0f && left.steerAngle == 0f, "Disable clears torque and steering");

            Set(driver, "frontRightWheel", left);
            Check(!(bool)Call(driver, "HasFrontWheels"), "Duplicate wheel references rejected");
            Set(driver, "frontRightWheel", right);
            right.motorTorque = 10f;
            Set(driver, "frontLeftWheel", null);
            Call(driver, "FixedUpdate");
            Check(right.motorTorque == 0f, "Missing wheel still clears surviving wheel torque");
            Set(driver, "frontLeftWheel", left);

            left.radius = 0.11f;
            left.suspensionDistance = 0.19f;
            left.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            var replacement = (WheelCollider)Call(driver, "PrepareWheelCollider", left, "Replacement");
            Check(replacement != left && Mathf.Approximately(replacement.radius, 0.11f)
                && Mathf.Approximately(replacement.suspensionDistance, 0.19f), "Runtime wheel replacement preserves radius and suspension distance");

            var container = car.AddComponent<SplineContainer>();
            container.Spline.Clear();
            Set(driver, "spline", container);
            Call(driver, "RefreshSplineLength");
            Check(Get<float>(driver, "splineLength") == 0f, "Empty spline is rejected");
            var mover = car.AddComponent<ConstantSplineMover>();
            Set(mover, "spline", container);
            Call(mover, "Awake");
            Check(true, "Simple mover handles empty spline");

            Debug.Log($"REVIEW_VERIFICATION_PASSED: {passed}");
        }
        finally
        {
            UnityEngine.Object.DestroyImmediate(car);
        }
    }

    private static WheelCollider Wheel(Transform parent, string name)
    {
        var wheel = new GameObject(name);
        wheel.transform.SetParent(parent, false);
        return wheel.AddComponent<WheelCollider>();
    }

    private static void Set(object target, string name, object value) => target.GetType().GetField(name, Flags).SetValue(target, value);
    private static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Flags).GetValue(target);
    private static object Call(object target, string name, params object[] args) => target.GetType().GetMethod(name, Flags).Invoke(target, args);
    private static void Check(bool condition, string description)
    {
        if (!condition) throw new Exception(description);
        passed++;
        Debug.Log("REVIEW_PASS: " + description);
    }
}
